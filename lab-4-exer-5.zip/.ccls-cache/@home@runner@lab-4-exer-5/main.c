#include <stdio.h>

int primo(int num) {
    if (num <= 1)
        return 0; 
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0)
            return 0; 
    }
    return 1; 
}

int main() {
    int n1, n2;

    printf("Digite dois números inteiros (N1 e N2): ");
    scanf("%d %d", &n1, &n2);
  
    if (n1 > n2) {
        int temp = n1;
        n1 = n2;
        n2 = temp;
    }
    printf("Números primos entre %d e %d:\n", n1, n2);
    for (int i = n1; i <= n2; i++) {
        if (primo(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");

    return 0;
}
