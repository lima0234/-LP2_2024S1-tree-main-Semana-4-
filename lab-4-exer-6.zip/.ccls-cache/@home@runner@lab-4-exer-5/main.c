#include <stdio.h>

float calcularSerie(int n) {
    float soma = 0.0f;
    int sinal = 1;

    for (int k = 1; k <= n; k++) {
        soma += sinal * (float)k / (k * k);
        sinal *= -1; 
    }

    return soma;
}

int main() {
    int n;

    printf("Digite um valor numérico: ");
    scanf("%d", &n);

    float resultado = calcularSerie(n);

    printf("O valor da série para n = %d é: %.10f\n", n, resultado);

    return 0;
}